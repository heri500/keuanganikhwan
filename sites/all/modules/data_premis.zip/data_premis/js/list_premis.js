jQuery(function ($) {
    $('.edit-premis').on('click', function (e){
        e.preventDefault();
        var splitID = $(this).attr('id').split('-');
        if (splitID.length > 0 && typeof splitID[2] != 'undefined'){
            window.location = Drupal.settings.basePath + 'masterdata/premis/add/'+ splitID[2];
        }
    });
    $('#new-premis').on('click', function (e){
        e.preventDefault();
        window.location = Drupal.settings.basePath + 'masterdata/premis/add';
    });
    $('.add-staff').on('click', function (e){
        e.preventDefault();
        var splitID = $(this).attr('id').split('-');
        if (splitID.length > 0 && typeof splitID[2] != 'undefined'){
            window.location = Drupal.settings.basePath + 'masterdata/premis/staff/'+ splitID[2];
        }
    });
    $('.add-oh').on('click', function (e){
        e.preventDefault();
        var splitID = $(this).attr('id').split('-');
        if (splitID.length > 0 && typeof splitID[2] != 'undefined'){
            window.location = Drupal.settings.basePath + 'masterdata/overhead/staff/'+ splitID[2];
        }
    });
})
