(function($) {

  $(document).ready(function() {
    // This command is used to initialize some elements and make them work properly
    $.material.init();
  });

})(jQuery);
